# Knife block: MJCF and OBJ for MuJoCo

A slanted beech knife block on rubber pads, with six knives: chef, bread, santoku, utility, boning, paring.

- `scene.xml` loads everything, each object attached from its own file at its place: `mujoco.MjModel.from_xml_path("scene.xml")`.
- `knife_block.xml`, `chef_20cm.xml`, `bread_20cm.xml`, `santoku_17cm.xml`, `utility_13cm.xml`, `boning_15cm.xml`, `paring_9cm.xml`: each object alone, its body at the origin.
- `meshes/`: the OBJ meshes and textures. Collision geoms are in group 3 and are convex pieces (MuJoCo collides every
  mesh as its convex hull); visual geoms are in group 2 and don't collide.
- Every body has an explicit `<inertial>` (mass, centre of mass, full inertia). Friction is set per geom from its
  part's material; `report.json` lists the materials, the acceptance checks and every probe.

Units are SI, z is up, quaternions are w x y z. Checked in MuJoCo 3.17.0: every file loads, and the scene settles
with no body drifting more than 1.3 mm in 1 s.

Exported by the Genesis workbench (github.com/earakely-scale/agentenv-genesis-plugin) after its checks, which run in
MuJoCo with Genesis as a second opinion.
